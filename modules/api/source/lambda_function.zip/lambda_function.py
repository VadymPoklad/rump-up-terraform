import boto3
import json
import os
from boto3.dynamodb.conditions import Key

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')

# Environment variable for DynamoDB table
TABLE_NAME = os.getenv('TABLE_NAME', 'UsersTable')
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    """
    Main Lambda handler to route API Gateway requests.
    """
    try:
        http_method = event['httpMethod']
        path = event['path']

        if http_method == 'GET' and path == '/user':
            return get_user(event)
        elif http_method == 'POST' and path == '/user':
            return create_user(event)
        elif http_method == 'PUT' and path == '/user':
            return update_user(event)
        elif http_method == 'DELETE' and path == '/user':
            return delete_user(event)
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Resource not found'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': str(e)})
        }

def get_user(event):
    """
    Retrieve a user by ID.
    """
    user_id = event['queryStringParameters'].get('id')  # Using .get to avoid KeyError
    if not user_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Missing user id in query parameters'})
        }
    
    response = table.get_item(Key={'id': user_id})
    if 'Item' in response:
        return {
            'statusCode': 200,
            'body': json.dumps(response['Item'])
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'User not found'})
        }

def create_user(event):
    """
    Create a new user.
    """
    body = json.loads(event['body'])
    user = {
        'id': body['id'],
        'name': body['name'],
        'email': body['email']
    }
    table.put_item(Item=user)
    return {
        'statusCode': 201,
        'body': json.dumps({'message': 'User created successfully'})
    }

def update_user(event):
    """
    Update an existing user.
    """
    body = json.loads(event['body'])
    user_id = body['id']
    update_expression = "SET #name = :name, email = :email"
    expression_values = {
        ':name': body['name'],
        ':email': body['email']
    }
    expression_names = {'#name': 'name'}

    table.update_item(
        Key={'id': user_id},
        UpdateExpression=update_expression,
        ExpressionAttributeValues=expression_values,
        ExpressionAttributeNames=expression_names
    )
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'User updated successfully'})
    }

def delete_user(event):
    """
    Delete a user by ID.
    """
    user_id = event['queryStringParameters'].get('id')  # Using .get to avoid KeyError
    if not user_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Missing user id in query parameters'})
        }
    
    table.delete_item(Key={'id': user_id})
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'User deleted successfully'})
    }
